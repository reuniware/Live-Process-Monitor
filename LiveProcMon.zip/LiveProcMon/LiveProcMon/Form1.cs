﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Diagnostics;

namespace LiveProcMon
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private Thread t = null;
        private void btnStartMonitoring_Click(object sender, EventArgs e)
        {
            lstProcesses.Clear();
            t = new Thread(myThread);
            t.Start();
            stopMonitoring = false;
        }

        private void btnStopMonitoring_Click(object sender, EventArgs e)
        {
            stopMonitoring = true;
        }


        private void log(string value)
        {
            if (InvokeRequired)
            {
                this.Invoke(new Action<string>(log), new object[] { value });
                return;
            }
            txtLog.Text += value + "\r\n";
            Utils.ScrollToBottom(txtLog);
        }

        private List<string> lstProcesses = new List<string>();
        private bool firstRunDone = false;
        private Process[] processes = null;
        private bool stopMonitoring = false;
        private string processData = "";
        private string[] tab = null;
        private string name = "";
        private int id = -1;
        private bool found = false;
        private bool killNewProcess = false; // Force killing of any new process (apart "cmd") ; a shortcut to cmd 
                                             // should be created on the desktop prior to launching this app

        private void myThread()
        {
            while (stopMonitoring == false)
            {
                if (firstRunDone == false)
                {
                    processes = Process.GetProcesses();
                    foreach (Process p in processes)
                    {
                        processData = p.ProcessName + "#" + p.Id;
                        lstProcesses.Add(processData);
                        log(DateTime.Now.ToString() + " : Initial process = " + processData);
                    }
                    firstRunDone = true;
                }
                else
                {
                    processes = Process.GetProcesses();
                    // pour chaque process sauvegardé, rechercher s'il existe toujours en mémoire
                    foreach (string processData in lstProcesses)
                    {
                        tab = processData.Split('#');
                        name = tab[0];
                        id = int.Parse(tab[1]);
                        found = false;
                        foreach (Process p in processes)
                        {
                            if (p.ProcessName.Equals(name) && (p.Id == id))
                            {
                                found = true;
                                break;
                            }
                        }
                        if (found == false)
                        {
                            log(DateTime.Now.ToString() + " : Process not in memory anymore = " + processData);
                            lstProcesses.Remove(processData);
                            break;
                        }
                    }

                    // pour chaque process en mémoire, rechercher s'il existe dans la liste des process sauvegardés
                    foreach (Process p in processes)
                    {
                        processData = p.ProcessName + "#" + p.Id;
                        if (!lstProcesses.Contains(processData))
                        {
                            lstProcesses.Add(processData);
                            log(DateTime.Now.ToString() + " : New process detected = " + processData);
                            if (killNewProcess == true)
                            {
                                if (!p.ProcessName.ToLower().Trim().Equals("cmd") && !p.ProcessName.ToLower().Trim().Equals("conhost"))
                                {
                                    try
                                    {
                                        p.Kill();
                                    }
                                    catch (Exception)
                                    {

                                    }
                                }
                            }
                        }
                    }
                }
                Thread.Sleep(250);
            }
        }

    }

    public class Utils
    {
        [System.Runtime.InteropServices.DllImport("user32.dll", CharSet = System.Runtime.InteropServices.CharSet.Auto)]
        private static extern int SendMessage(System.IntPtr hWnd, int wMsg, System.IntPtr wParam, System.IntPtr lParam);

        private const int WM_VSCROLL = 0x115;
        private const int SB_BOTTOM = 7;

        /// <summary>
        /// Scrolls the vertical scroll bar of a multi-line text box to the bottom.
        /// </summary>
        /// <param name="tb">The text box to scroll</param>
        public static void ScrollToBottom(System.Windows.Forms.TextBox tb)
        {
            if (System.Environment.OSVersion.Platform != System.PlatformID.Unix)
                SendMessage(tb.Handle, WM_VSCROLL, new System.IntPtr(SB_BOTTOM), System.IntPtr.Zero);
        }


    }
}
